/*
 * SPDX-License-Identifier: GPL-2.0-only
 */

// Network topology
//
//       n0    n1   n2   n3
//       |     |    |    |
//       =================
//              LAN
//
// - UDP flows from n0 to n1 and back
// - DropTail queues
// - Tracing of queues and packet receptions to file "udp-echo.tr"

#include "ns3/applications-module.h"
#include "ns3/core-module.h"
#include "ns3/csma-module.h"
#include "ns3/internet-module.h"

#include <fstream>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("RealtimeUdpEchoExample");

int
main(int argc, char* argv[])
{
    //
    // Allow the user to override any of the defaults and the above Bind() at
    // run-time, via command-line arguments
    //
    CommandLine cmd(__FILE__);
    cmd.Parse(argc, argv);

    //
    // But since this is a realtime script, don't allow the user to mess with
    // that.
    //
    GlobalValue::Bind("SimulatorImplementationType", StringValue("ns3::RealtimeSimulatorImpl"));

    //
    // Explicitly create the nodes required by the topology (shown above).
    //
    NS_LOG_INFO("Create nodes.");
    NodeContainer n;
    n.Create(4);

    InternetStackHelper internet;
    internet.Install(n);

    //
    // Explicitly create the channels required by the topology (shown above).
    //
    NS_LOG_INFO("Create channels.");
    CsmaHelper csma;
    csma.SetChannelAttribute("DataRate", DataRateValue(DataRate(5000000)));
    csma.SetChannelAttribute("Delay", TimeValue(MilliSeconds(2)));
    csma.SetDeviceAttribute("Mtu", UintegerValue(1400));
    NetDeviceContainer d = csma.Install(n);

    //
    // We've got the "hardware" in place.  Now we need to add IP addresses.
    //
    NS_LOG_INFO("Assign IP Addresses.");
    Ipv4AddressHelper ipv4;
    ipv4.SetBase("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer i = ipv4.Assign(d);

    NS_LOG_INFO("Create Applications.");

    //
    // Create a UdpEchoServer application on node one.
    //
    uint16_t port = 9; // well-known echo port number
    UdpEchoServerHelper server(port);
    ApplicationContainer apps = server.Install(n.Get(1));
    apps.Start(Seconds(1));
    apps.Stop(Seconds(10));

    //
    // Create a UdpEchoClient application to send UDP datagrams from node zero to
    // node one.
    //
    uint32_t packetSize = 1024;
    uint32_t maxPacketCount = 500;
    Time interPacketInterval = Seconds(0.01);
    UdpEchoClientHelper client(i.GetAddress(1), port);
    client.SetAttribute("MaxPackets", UintegerValue(maxPacketCount));
    client.SetAttribute("Interval", TimeValue(interPacketInterval));
    client.SetAttribute("PacketSize", UintegerValue(packetSize));
    apps = client.Install(n.Get(0));
    apps.Start(Seconds(2));
    apps.Stop(Seconds(10));

    AsciiTraceHelper ascii;
    csma.EnableAsciiAll(ascii.CreateFileStream("realtime-udp-echo.tr"));
    csma.EnablePcapAll("realtime-udp-echo", false);

    //
    // Now, do the actual simulation.
    //
    Simulator::Stop(Seconds(11));
    NS_LOG_INFO("Run Simulation.");
    Simulator::Run();
    Simulator::Destroy();
    NS_LOG_INFO("Done.");

    return 0;
}
